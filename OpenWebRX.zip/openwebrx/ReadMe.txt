/etc/openwebrx/openwebrx.conf

/var/lib/openwebrx/bookmarks.json
/var/lib/openwebrx/receiver_avatar.png
/var/lib/openwebrx/settings.json
/var/lib/openwebrx/users.json
